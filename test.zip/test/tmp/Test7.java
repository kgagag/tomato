public class Test7 {

    static int age ;

    public static void main(String[] args) {
        age = 100;
        int b = 200 + age;
    }
    
}