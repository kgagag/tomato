public class Test11 {
    
    static double add (double a,double b){
        return a + b;
    }

    public static void main(String[] args) {
        add(100d, 200d);
    }
}
