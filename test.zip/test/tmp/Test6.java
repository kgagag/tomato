public class Test6 {
    public static void main(String[] args) {
        int a = 100;
        float b = 100.5f;
        double c = 200.006;
        short d = 20;
        double e = a + b + c + d;
        //System.out.println(e);
    }
}
