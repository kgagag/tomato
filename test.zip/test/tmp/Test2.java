public class Test2 {
    public static void main(String[] args) {
        Test2 test2 = new Test2();
        int c = test2.add(100,200) + 300;
    }

    public int add(int a,int b){
        return a + b;
    }
}
