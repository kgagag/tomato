public class Test4 {
    public static void main(String[] args) {
        int a = 1000;
        char c = '张';
        int e = a + c;
        System.out.println(c);
    }
}
