public class Test {
    private int age;
    public static void main(String[] args) {
       
        Person person = new Person(100);

        int a = 100;
        int b = a + person.getAge();

    }
}