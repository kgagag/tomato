public class Test1 {
    int add(int a , int b){
        return a + b;
    }

    public boolean test(){
        int a = 1000;
        int b = 666;
        if(add(a, b) == 1666){
            return true;
        }
        return false;
    }
}
