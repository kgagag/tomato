public class Test5 {
    public static void main(String[] args) {
        int[] arr = new int[1000];
        arr[5] = 100;
        arr[7] = 800;
        int c = arr[5] + arr[7];
    }
}
