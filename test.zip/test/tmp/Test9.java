public class Test9 {

    static double add(double a ,int b){
        return a + b;
    }

    public static void main(String[] args) {
     double a =   add(200d, 300);
     double b = a + 500;
    }
}
