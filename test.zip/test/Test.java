public class Test {
    public static void main(String[] args) throws Exception{
        new Test1().test();
        new Test1().test();
        new Test1().test();
        new Test1().test();
        new Test1().test();
        new Test1().test();

        // int a = 10;
        // int b = 20;
        // int c = a + b;
    }
}
