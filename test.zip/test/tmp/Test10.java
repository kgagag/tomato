public class Test10 {
    public static void main(String[] args) {
        double a = 100.001d;
        double b = a + 100;
    }
}
