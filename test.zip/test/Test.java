public class Test {
    public static void main(String[] args) throws Exception{
        if(new Test1().test()){
            LogUtil.log("Test1 测试通过 \n");
        }else{
            LogUtil.log("Test1 测试失败 \n");
        }
    }
}
