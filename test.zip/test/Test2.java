import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.imageio.stream.FileImageInputStream;

public class Test2 {
    public static void main(String[] args) throws Exception {
        FileOutputStream out = new FileOutputStream("E:/ttt.txt");

    }
}
